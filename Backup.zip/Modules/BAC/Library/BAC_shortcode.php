<?php

namespace Modules\Bac\Library;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Carbon\Carbon;

/**
*   Class : ApplicantDatatables
*   methods : applicants datatables
*/
class BAC_shortcode
{
    $code_list = array(
            ' [department]'
        );
}

?>