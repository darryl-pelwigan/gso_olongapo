<?php

namespace Modules\BAC\Entities;

use Illuminate\Database\Eloquent\Model;

class bacCategory extends Model
{
    protected $table = 'olongapo_bac_category';
    protected $fillable = ['description'];



}
