<?php

return [
    'name' => 'GSOassistant'
];
