<?php

return [
    'name' => 'Administrator'
];
