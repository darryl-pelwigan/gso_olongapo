<?php

return [
    'name' => 'Department'
];
