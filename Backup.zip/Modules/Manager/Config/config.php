<?php

return [
    'name' => 'Manager'
];
