<?php

namespace Modules\Abstrct\Entities;

use Illuminate\Database\Eloquent\Model;


class AbstrctSignee extends Model
{
    protected $table = 'olongapo_absctrct_signee';
    protected $fillable = ['*'];
}
