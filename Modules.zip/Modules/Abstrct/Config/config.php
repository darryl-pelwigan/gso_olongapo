<?php

return [
    'name' => 'Abstrct'
];
