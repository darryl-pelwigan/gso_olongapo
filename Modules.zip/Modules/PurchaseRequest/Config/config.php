<?php

return [
    'name' => 'PurchaseRequest'
];
