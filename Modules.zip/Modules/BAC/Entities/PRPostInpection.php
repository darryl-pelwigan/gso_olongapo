<?php

namespace Modules\BAC\Entities;

use Illuminate\Database\Eloquent\Model;

class PRPostInpection extends Model
{
    protected $table = 'olongapo_purchase_request_post_inspection';
    protected $fillable = ['*'];
}
