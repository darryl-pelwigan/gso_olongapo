<?php

namespace Modules\BAC\Entities;

use Illuminate\Database\Eloquent\Model;

class BacType extends Model
{
	protected $table = 'olongapo_bac_type';
    protected $fillable = [];
}
