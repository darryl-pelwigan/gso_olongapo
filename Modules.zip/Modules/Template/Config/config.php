<?php

return [
    'name' => 'Template'
];
