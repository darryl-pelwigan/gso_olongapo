<?php

return [
    'name' => 'Employee'
];
