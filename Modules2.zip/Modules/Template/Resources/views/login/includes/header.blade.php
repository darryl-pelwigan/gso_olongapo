
  <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
        <div class="col-sm-5 col-xs-5">
          <a href="#" class="navbar-brand"><b><img class="img-responsive" src="{{asset('olongapo')}}/img/logo-360.png"></b></a>
        </div>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>

        </div>



      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>
  <div class="logo-wrap"><div class="jhmc-logo"></div></div>