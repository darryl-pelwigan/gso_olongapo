<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <strong>Copyright &copy; {{Carbon\Carbon::now()->format('Y')}} <a href="https://new.danalexintl.com"><span style="color: #000;">DAN</span><span style="color: #034802 ;">ALEX</span> Corporation</a></strong> All rights
      reserved.
    </div>
    
  </footer>