<!-- jQuery 2.2.3 -->
<script src="{{asset('adminlte')}}/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="{{asset('adminlte')}}/bootstrap/js/bootstrap.min.js"></script>

