<link rel="shortcut icon" href="{{asset('img')}}/logo2.ico" type="image/x-icon">

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="{{asset('adminlte')}}/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{asset('adminlte')}}//bootstrap/font-awesome/css/font-awesome.min.css">

      <link rel="stylesheet"  href="{{asset('pdf')}}/css/pdf-fonts.css">

    <link rel="stylesheet" href="{{asset('pdf')}}/css/bac-style.css">


