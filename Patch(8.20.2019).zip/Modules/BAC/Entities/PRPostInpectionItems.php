<?php

namespace Modules\BAC\Entities;

use Illuminate\Database\Eloquent\Model;

class PRPostInpectionItems extends Model
{
    protected $table = 'olongapo_purchase_request_post_inspection_items';
    protected $fillable = ['*'];
}
